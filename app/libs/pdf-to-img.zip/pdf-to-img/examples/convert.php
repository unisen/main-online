<?php
$image = new imagick();
$image->setResolution(300, 300);
$image->readImage('foto.pdf');
$image->setImageCompressionQuality(100);
$image->writeImages('high_quality.jpg', false);