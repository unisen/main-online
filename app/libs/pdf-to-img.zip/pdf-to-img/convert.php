<?php

if (isset($_GET['params_convert'])) {
    $params = $_GET['params_convert'];

    /* $params['width'] = 300;
    $params['height'] = 300;
    $params['compress'] = 100;
    $params['pdf_file'] = 'file3.pdf';
    $params['file_output'] = 'file3.jpg'; */    

    $image = new imagick();
    $image->setResolution($params['width'], $params['height']);
    $image->readImage($params['pdf_file']);
    $image->setImageCompressionQuality($params['compress']);
    $image->writeImages($params['file_output'], false);

}
/* $params['width'] = 300;
    $params['height'] = 300;
    $params['compress'] = 100;
    $params['pdf_file'] = 'file3.pdf';
    $params['file_output'] = 'file3.jpg'; */

$image = new imagick();
$image->setResolution(300, 300);
$image->readImage('file5.pdf');
$image->setImageCompressionQuality(100);
$image->writeImages('file5.jpg', false);