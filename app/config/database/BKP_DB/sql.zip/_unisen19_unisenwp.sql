--
-- Banco de dados: `unisen19_unisenwp`
--
CREATE DATABASE IF NOT EXISTS `unisen19_unisenwp` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `unisen19_unisenwp`;
