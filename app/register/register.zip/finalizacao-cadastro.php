<?php 

require_once '../config/database/conexao.php';

$sql_tipos_docs = "SELECT * FROM tipos_documentos";
$tipos_documentos = mysqli_query($con,$sql_tipos_docs);

while($row = mysqli_fetch_array($tipos_documentos, MYSQLI_ASSOC)) : 
    $id_doc = $row['id'];
    $nome_doc = $row['documento'];
    echo "$id_doc - $nome_doc<br>";                           
endwhile;

$con->close();